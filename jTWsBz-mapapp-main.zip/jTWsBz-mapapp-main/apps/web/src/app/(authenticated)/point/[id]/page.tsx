'use client'

import {
  MrbCard,
  MrbLoader,
  MrbRow,
  MrbToast,
  MrbTypography,
} from '@web/designSystem'
import { PageLayout } from '@web/layouts/Page.layout'
import { useAuthentication } from '@web/modules/authentication'
import { useParams, useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'

export default function ViewPointPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(true)

  // You can store items to display here
  const [item, setItem] = useState([])

  useEffect(() => {
    // You can fetch item here
  }, [])

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}

      {!isLoading && (
        <MrbCard>
          <MrbCard.Body>
            <MrbRow horizontal="center">
              {/* You can set the cover picture with MrbImage size=medium if relevant */}
            </MrbRow>
            <MrbRow horizontal="center">
              <MrbTypography variant="h3">
                {/* main title/name of the card */}
              </MrbTypography>
            </MrbRow>
            {/* You can set body here: use MrbDescriptionList and MrbDescription to display multiple data attributes or just MrbTypograph to display content */}
          </MrbCard.Body>
          <MrbCard.Footer>
            <MrbRow horizontal="right" gap={1}>
              {/* You can set bottom right actions here if there is any actions */}
            </MrbRow>
          </MrbCard.Footer>
        </MrbCard>
      )}
    </PageLayout>
  )
}