'use client'

import {
  MrbButton,
  MrbCard,
  MrbForm,
  MrbToast,
  MrbTypography,
} from '@web/designSystem'
import { PageLayout } from '@web/layouts/Page.layout'
import { useAuthentication } from '@web/modules/authentication'
import { useParams, useRouter } from 'next/navigation'
import { useState } from 'react'

export default function AddNewPointPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(false)

  const handleSubmit = values => {
    setLoading(true)
    // Handle the form submission here

    setLoading(false)
  }

  return (
    <PageLayout layout="narrow">
      <MrbTypography variant="h1" className="mb-1">
        {/* Set the title here */}
      </MrbTypography>
      <MrbCard size="full-width">
        <MrbCard.Body>
          <MrbForm
            onSubmit={handleSubmit}
            inputs={
              [
                // List all the form inputs here
              ]
            }
          >
            <MrbButton variant="primary" type="submit" isLoading={isLoading}>
              Create
            </MrbButton>
          </MrbForm>
        </MrbCard.Body>
      </MrbCard>
    </PageLayout>
  )
}