'use client'

import { useHttpAction } from '@web/core/http/http.action.hook'
import { useCoreStore } from '@web/core/store'
import { MrbRow, MrbTypography } from '@web/designSystem'
import { NotificationApi } from '@web/domain/notification'
import { PageLayout } from '@web/layouts/Page.layout'
import { useNotificationToast } from '@web/modules/notification/components'
import { Actions } from './components/Actions'
import { NotificationList } from './components/NotificationList'

export default function NotificationsPage() {
  const { notifications, setNotifications } = useCoreStore()

  const notificationToast = useNotificationToast()
  const actionClearAll = useHttpAction()

  const handleClearAll = () => {
    actionClearAll.run(() =>
      NotificationApi.deleteAllByMe().then(() => setNotifications([])),
    )
  }

  const canClearAll = notifications.length > 0

  return (
    <PageLayout layout="super-narrow">
      <MrbRow horizontal="between" vertical="center" gap={1}>
        <MrbTypography variant="h2">Notifications</MrbTypography>

        <Actions
          canClearAll={canClearAll}
          isLoadingClearAll={actionClearAll.isLoading}
          onClearAll={handleClearAll}
        />
      </MrbRow>

      <NotificationList
        notifications={notifications}
        onClick={notificationToast.onClick}
        onDelete={notificationToast.onDelete}
      />
    </PageLayout>
  )
}
