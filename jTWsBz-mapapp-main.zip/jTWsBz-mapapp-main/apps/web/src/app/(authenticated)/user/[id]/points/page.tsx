'use client'

import {
  MrbCol,
  MrbEmptyState,
  MrbList,
  MrbLoader,
  MrbRow,
  MrbToast,
  MrbTypography,
} from '@web/designSystem'
import { PageLayout } from '@web/layouts/Page.layout'
import { useAuthentication } from '@web/modules/authentication'
import { useParams, useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'

export default function UserPointsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(true)

  // You can store items to display here
  const [items, setItems] = useState([])

  useEffect(() => {
    // You can fetch items to display here
  }, [])

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}

      {!isLoading && (
        <>
          {items?.length === 0 && (
            <MrbEmptyState>
              There is no items to be display.
              {/* You can set a button to redirect to the item creation page if relevant */}
            </MrbEmptyState>
          )}
          <MrbList divider={false}>
            {items?.map(item => (
              <MrbList.Item
                key={item.id}
                onClick={() => {
                  router.push('/')
                }}
              >
                <MrbRow gap={2} className="mrb-fill-x">
                  <MrbCol>
                    {/* You can set the cover picture if there is here size=small */}
                  </MrbCol>
                  <MrbCol xs="fill" gap={1}>
                    <MrbTypography variant="h3">
                      {/* main title/name of the element */}
                    </MrbTypography>

                    {/* You can set body here: use MrbDescriptionList (with orientation='horizontal' ) and MrbDescription to display multiple data attributes or just MrbTypograph to display content */}

                    <MrbRow horizontal="right" gap={1}>
                      {/* You can set bottom right actions here */}
                    </MrbRow>
                  </MrbCol>
                </MrbRow>
              </MrbList.Item>
            ))}
          </MrbList>
        </>
      )}
    </PageLayout>
  )
}