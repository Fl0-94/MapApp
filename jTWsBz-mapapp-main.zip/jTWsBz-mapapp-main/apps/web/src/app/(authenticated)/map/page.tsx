'use client'

import {
  MrbCard,
  MrbEmptyState,
  MrbGrid,
  MrbGridItem,
  MrbLoader,
  MrbRow,
  MrbToast,
  MrbTypography,
} from '@web/designSystem'
import { PageLayout } from '@web/layouts/Page.layout'
import { useAuthentication } from '@web/modules/authentication'
import { useParams, useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'

export default function MapViewPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(true)

  // You can store items to display here
  const [items, setItems] = useState([])

  useEffect(() => {
    // You can fetch items to display here
  }, [])

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}

      {!isLoading && (
        <>
          {items?.length === 0 && (
            <MrbEmptyState>
              There is no items to be display.
              {/* You can set a button to redirect to the item creation page if relevant */}
            </MrbEmptyState>
          )}
          <MrbGrid gap={2}>
            {items?.map(item => (
              <MrbGridItem xs={12} sm={12} md={6} lg={6} xl={4} key={item.id}>
                <MrbCard
                  className="mrb-fill-y"
                  onClick={() => {
                    router.push('path of the item')
                  }}
                >
                  <MrbCard.Body>
                    <MrbRow horizontal="center">
                      {/* You can set the picture if there is here */}
                    </MrbRow>
                    <MrbRow horizontal="center">
                      <MrbTypography variant="h3">
                        {/* You can set the title of the card here  */}
                      </MrbTypography>
                    </MrbRow>
                    <MrbRow>{/* You can set body here */}</MrbRow>
                  </MrbCard.Body>
                  <MrbCard.Footer>
                    <MrbRow horizontal="around">
                      {/* You can set bottom right actions here */}
                    </MrbRow>
                  </MrbCard.Footer>
                </MrbCard>
              </MrbGridItem>
            ))}
          </MrbGrid>
        </>
      )}
    </PageLayout>
  )
}