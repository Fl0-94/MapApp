'use client'

import { useCoreStore } from '@web/core/store'
import { MrbNotification, MrbToast } from '@web/designSystem'
import { Notification, useNotificationCreated } from '@web/domain/notification'
import { AuthenticationGuard } from '@web/modules/authentication'
import { useNotificationToast } from '@web/modules/notification/components'

import { UserCodeVerification } from '@web/modules/user/components'
import { ReactNode } from 'react'

export default function AuthenticatedLayout({
  children,
}: {
  children: ReactNode
}) {
  const store = useCoreStore()
  const toast = MrbToast.useToast()

  const notificationToast = useNotificationToast()

  useNotificationCreated((notification: Notification) => {
    const notificationsUpdated = [...store.notifications]

    notificationsUpdated.push(notification)

    store.setNotifications(notificationsUpdated)

    toast.plain(
      <MrbNotification
        notification={notification}
        {...notificationToast}
        isPreview={true}
      />,
    )
  })

  return (
    <AuthenticationGuard>
      <UserCodeVerification>{children}</UserCodeVerification>
    </AuthenticationGuard>
  )
}
