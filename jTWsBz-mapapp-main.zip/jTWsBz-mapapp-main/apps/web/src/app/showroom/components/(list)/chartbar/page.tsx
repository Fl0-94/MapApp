'use client'

import { MrbChartBar } from '@web/designSystem'

export default function ChartBar() {
  const data = {
    labels: [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ],
    datasets: [
      {
        label: 'Revenue',
        data: [
          12000, 19000, 17000, 22000, 25000, 21000, 23000, 19000, 26000, 28000,
          24000, 29000,
        ],
      },
      {
        label: 'Profit',
        data: [
          6000, 1900, 1700, 2200, 6000, 2100, 2300, 6000, 2600, 2800, 2400,
          6000,
        ],
      },
    ],
  }

  return (
    <>
      <MrbChartBar data={data} />
    </>
  )
}
