'use client'

import { MrbPDF } from '@web/designSystem'

export default function PDFShow() {
  return (
    <>
      <MrbPDF
        src="https://slicedinvoices.com/pdf/wordpress-pdf-invoice-plugin-sample.pdf"
        toolbar={true}
        leftbar={false}
      />
    </>
  )
}
