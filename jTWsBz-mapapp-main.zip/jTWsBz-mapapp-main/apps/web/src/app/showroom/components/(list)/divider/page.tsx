'use client'

import { MrbDivider } from '@web/designSystem'

export default function DividerShow() {
  return (
    <>
      <p>One text</p>
      <MrbDivider />
      <p>Two Text</p>
    </>
  )
}
