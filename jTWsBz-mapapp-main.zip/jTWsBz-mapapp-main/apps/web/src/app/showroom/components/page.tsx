'use client'

export default function ShowroomComponentsPage() {
  return <div></div>
}
