'use client'

import { ConfigurationProvider } from '@web/core/configuration'
import { CoreStoreProvider } from '@web/core/store'
import { MrbHtml, MrbMain } from '@web/designSystem'
import { Michelangelo } from '@web/libraries/michelangelo'
import { AuthenticationProvider } from '@web/modules/authentication'
import { GoogleOauth } from '@web/modules/googleOauth'
import { ReactNode } from 'react'
import { SocketProvider } from '../core/socket'
import './main.scss'

export default function AppLayout({ children }: { children: ReactNode }) {
  return (
    <>
      <MrbHtml>
        <ConfigurationProvider>
          <GoogleOauth.Provider>
            <CoreStoreProvider>
              <AuthenticationProvider>
                <SocketProvider>
                  <Michelangelo />
                  <MrbMain name="MapApp ">{children}</MrbMain>
                </SocketProvider>
              </AuthenticationProvider>
            </CoreStoreProvider>
          </GoogleOauth.Provider>
        </ConfigurationProvider>
      </MrbHtml>
    </>
  )
}
