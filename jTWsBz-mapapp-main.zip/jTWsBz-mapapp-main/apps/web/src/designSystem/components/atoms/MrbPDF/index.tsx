'use client'

import { MrbComponent } from '../../../helpers/common'
import { PropsHTML, Styled } from './styled'

/**
 * @component MrbPDF
 * @example example.txt
 * @description Component to display a PDF in the application.
 * @prop {ReactNode} src - The URL of the pdf @required
 */

interface Props extends PropsHTML {
  src: string
  toolbar?: boolean
  leftbar?: boolean
}

const { Wrapper, Object } = Styled

export const MrbPDF: MrbComponent<Props, typeof Styled> = ({
  src,
  toolbar = true,
  leftbar = false,
  ...props
}) => {
  return (
    <Wrapper {...props}>
      <Object
        type="application/pdf"
        data={`${src}#toolbar=${toolbar ? 1 : 0}&navpanes=${leftbar ? 1 : 0}`}
      ></Object>
    </Wrapper>
  )
}

MrbPDF.Styled = Styled
