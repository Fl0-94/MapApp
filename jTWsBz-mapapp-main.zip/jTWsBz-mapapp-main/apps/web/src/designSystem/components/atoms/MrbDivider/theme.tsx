export interface MrbDividerTheme {
  color?: string
}
