export interface MrbListTheme {
  divider?: {
    border?: string
  }
  item?: {
    hover?: {
      background?: string
    }
  }
}
