export interface MrbStepperTheme {
  active?: {
    color: string
    borderColor: string
  }
  disabled?: {
    color: string
    borderColor: string
  }
}
