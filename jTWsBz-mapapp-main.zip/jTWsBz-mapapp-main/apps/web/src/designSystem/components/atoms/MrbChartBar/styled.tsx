import { HTMLAttributes } from 'react'
import styled from 'styled-components'

export interface PropsHTML extends HTMLAttributes<HTMLDivElement> {}

interface PropsStyle {}

/* --------------------------------- WRAPPER -------------------------------- */
const Wrapper = styled.div<PropsStyle>`
  width: 100%;
  height: 100%;
`

const Object = styled.object<PropsStyle>`
  width: 100%;
  height: 100%;
`

export const Styled = {
  Wrapper,
  Object,
}
