export interface MrbTypographyTheme {
  h1: {
    color: string
  }
  h2: {
    color: string
  }
  h3: {
    color: string
  }
  primary: {
    color: string
  }
  secondary: {
    color: string
  }
  caption: {
    color: string
  }
}
