'use client'

import {
  BarElement,
  CategoryScale,
  ChartData,
  Chart as ChartJS,
  ChartOptions,
  Legend,
  LinearScale,
  Title,
  Tooltip,
} from 'chart.js'
import { Bar } from 'react-chartjs-2'
import { MrbComponent } from '../../../helpers/common'
import { Theme } from '../../../theme'
import { PropsHTML, Styled } from './styled'
/**
 * @component MrbChartBar
 * @example example.txt
 * @description Component to display a Bar Chart
 * @prop {ChartData<'bar'>} data - The ChartJS data prop @required
 * @prop {ChartOptions<'bar'>} options - The ChartJS prop element
 */

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend)

const ThemeChart = Theme.components.chart

interface Props extends PropsHTML {
  data: ChartData<'bar'>
  options?: ChartOptions<'bar'>
}

const { Wrapper, Object } = Styled

export const MrbChartBar: MrbComponent<Props, typeof Styled> = ({
  data,
  options,
  ...props
}) => {
  const optionsChart = options ?? {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
    },
  }

  const dataWithColors = {
    ...data,
    datasets: data.datasets.map((dataset, index) => ({
      ...dataset,
      backgroundColor:
        ThemeChart.colors[index % (ThemeChart.colors.length + 1)],
    })),
  }

  return (
    <Wrapper {...props}>
      <Bar data={dataWithColors} options={optionsChart} />
    </Wrapper>
  )
}

MrbChartBar.Styled = Styled
