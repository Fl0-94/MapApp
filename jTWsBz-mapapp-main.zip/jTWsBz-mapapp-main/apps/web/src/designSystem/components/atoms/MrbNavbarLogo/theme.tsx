export interface MrbNavbarLogoTheme {
  color: string
  background: string
  border: string
  borderRadius?: string
  shadowColor?: string
}
