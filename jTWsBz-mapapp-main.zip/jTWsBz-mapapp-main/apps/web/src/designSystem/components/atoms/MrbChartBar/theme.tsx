export interface MrbChartTheme {
  colors: string[]
}
