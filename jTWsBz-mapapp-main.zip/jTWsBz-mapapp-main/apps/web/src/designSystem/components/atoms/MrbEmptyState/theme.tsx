export interface MrbEmptyStateTheme {
  color?: string
  background?: string
  border?: string
  boxShadow?: string
}
