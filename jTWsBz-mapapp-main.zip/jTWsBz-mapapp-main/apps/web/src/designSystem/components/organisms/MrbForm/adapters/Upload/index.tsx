import { useHttpAction } from '@web/core/http/http.action.hook'
import { MrbUpload } from '@web/designSystem/components/molecules/MrbUpload'
import { UploadApi } from '@web/domain/upload'
import { useEffect } from 'react'
import { InputConfigurationManager } from '../../domain/inputConfiguration'
import { InputFamilyDefault } from '../../inputFamily/inputFamily.default'
import { AdapterElement } from '../adapter'

export const UploadAdapter: React.FC<AdapterElement> = ({
  values,
  input,
  settings,
  onChange,
  onError,
}) => {
  const inputFamily = new InputFamilyDefault({ input })

  const value = inputFamily.findValue(values)

  const props = InputConfigurationManager.getProps(input)

  const fromUrlToFile = () => {
    if (value) {
      return {
        name: value.split('/').slice(-1)[0],
      }
    }
  }

  const queryUpload = useHttpAction({ defaultData: fromUrlToFile() })

  useEffect(() => {
    const errorKey = inputFamily.getErrorKey()

    const errors = inputFamily.checkAndGetErrors(values)

    onError({ key: errorKey, errors })

    return () => {
      onError({ key: errorKey, errors: [] })
    }
  }, [])

  const handleBlur = ({ value }) => {
    const valuesUpdated = inputFamily.setValue(values, value)

    const errorKey = inputFamily.getErrorKey()

    const errors = inputFamily.checkAndGetErrors(valuesUpdated)

    onChange({ values: valuesUpdated })

    onError({ key: errorKey, errors })
  }

  const onUpload = async ({ file }) => {
    const formData = new FormData()

    formData.append('file', file)

    queryUpload.run(() =>
      UploadApi.upload(formData).then(url => {
        handleBlur({ value: url })

        return file
      }),
    )
  }

  const onDelete = () => {
    queryUpload.clear()

    handleBlur({ value: undefined })
  }

  return (
    <>
      <MrbUpload
        {...props}
        defaultValue={value}
        file={queryUpload.data}
        isLoading={queryUpload.isLoading}
        isError={!!queryUpload.error}
        onUpload={onUpload}
        onDelete={onDelete}
      />
    </>
  )
}
