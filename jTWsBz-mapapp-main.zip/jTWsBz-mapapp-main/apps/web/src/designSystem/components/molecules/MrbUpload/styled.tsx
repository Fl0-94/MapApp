import { InputHTMLAttributes } from 'react'
import styled from 'styled-components'

export interface PropsHTML
  extends Omit<InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'onBlur'> {}

const InputHidden = styled.input`
  display: none;
`

const Wrapper = styled.div``

export const Styled = {
  InputHidden,
  Wrapper,
}
