'use client'

import { Utility } from '@web/libraries/utility'
import { useRef } from 'react'
import { MrbComponent } from '../../../helpers/common'
import { MrbTypography } from '../../atoms'
import { MrbButton } from '../../atoms/MrbButton'
import { MrbIcon } from '../../atoms/MrbIcon'
import { PropsHTML, Styled } from './styled'

/**
 * @component MrbUpload
 * @description A file upload component.
 */

export type UploadStatus = 'initial' | 'uploading' | 'success' | 'fail'

interface Props extends PropsHTML {
  defaultValue?: string
  status?: UploadStatus
  file?: File
  isLoading?: boolean
  isError?: boolean
  onUpload?: ({ file }) => void
  onDelete?: () => void
}

const { Wrapper, InputHidden } = Styled

export const MrbUpload: MrbComponent<Props> = ({
  file,
  isLoading = false,
  isError,
  onUpload,
  onDelete,
  ...props
}) => {
  const refInput = useRef(null)

  const handleClickUpload = () => {
    refInput.current.click()
  }

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]

    const isFile = Utility.isDefined(file)

    if (isFile) {
      onUpload({ file })
    }
  }

  const canUpload = Utility.isNull(file)

  const isUploaded = Utility.isDefined(file)

  return (
    <Wrapper {...props}>
      {canUpload && (
        <MrbButton onClick={handleClickUpload} isLoading={isLoading}>
          <MrbIcon name="upload-2-line" /> Upload a file
        </MrbButton>
      )}

      {isUploaded && (
        <MrbButton onClick={onDelete} isLoading={isLoading}>
          {file.name} <MrbIcon name="close" />
        </MrbButton>
      )}

      {isError && (
        <MrbTypography variant="danger" className="pt-1">
          Upload failed. Try again.
        </MrbTypography>
      )}

      <InputHidden ref={refInput} type="file" onChange={handleFileChange} />
    </Wrapper>
  )
}

MrbUpload.Styled = Styled
