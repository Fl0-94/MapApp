import { Module } from '@nestjs/common'
import { ServeStaticModule } from '@nestjs/serve-static'
import { join } from 'path'
import { UploadLocalProvider } from './internal/providers/local/upload.local.provider'
import { UploadService } from './upload.service'

@Module({
  imports: [
    ServeStaticModule.forRoot({
      rootPath: join(__dirname, '..', `..${UploadLocalProvider.path}`),
      serveRoot: UploadLocalProvider.path,
    }),
  ],
  providers: [UploadService],
  exports: [UploadService],
})
export class UploadModule {}
