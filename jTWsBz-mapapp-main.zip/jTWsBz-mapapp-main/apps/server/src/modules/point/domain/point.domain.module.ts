import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { PointDomainFacade } from './point.domain.facade'
import { Point } from './point.model'

@Module({
  imports: [
    TypeOrmModule.forFeature([Point]),
    DatabaseHelperModule,
  ],
  providers: [
    PointDomainFacade,
    PointDomainFacade,
  ],
  exports: [PointDomainFacade],
})
export class PointDomainModule {}
