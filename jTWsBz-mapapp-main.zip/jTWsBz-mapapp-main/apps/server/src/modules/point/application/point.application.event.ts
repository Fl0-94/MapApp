export namespace PointApplicationEvent {
  export namespace PointCreated {
    export const key = 'point.application.point.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
