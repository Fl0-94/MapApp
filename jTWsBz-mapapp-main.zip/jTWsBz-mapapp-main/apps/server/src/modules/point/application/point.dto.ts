import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class PointCreateDto {

@IsNumber()

@IsNotEmpty()
  latitude: number

@IsNumber()

@IsNotEmpty()
  longitude: number

@IsString()

@IsOptional()
  userId?: string

@IsString()

@IsOptional()
  dateCreated?: string

@IsString()

@IsOptional()
  dateDeleted?: string

@IsString()

@IsOptional()
  dateUpdated?: string

}

export class PointUpdateDto {

@IsNumber()

@IsOptional()
  latitude?: number

@IsNumber()

@IsOptional()
  longitude?: number

@IsString()

@IsOptional()
  userId?: string

@IsString()

@IsOptional()
  dateCreated?: string

@IsString()

@IsOptional()
  dateDeleted?: string

@IsString()

@IsOptional()
  dateUpdated?: string

}
