import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  Point,
  PointDomainFacade,
} from '@server/modules/point/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { PointApplicationEvent } from './point.application.event'
import {
  PointCreateDto,
  PointUpdateDto,
} from './point.dto'

@Controller('/v1/points')
export class PointController {
  constructor(
    private eventService: EventService,
    private pointDomainFacade: PointDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.pointDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: PointCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.pointDomainFacade.create(body)

    await this.eventService.emit<PointApplicationEvent.PointCreated.Payload>(
      PointApplicationEvent
        .PointCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:pointId')
  async findOne(
    @Param('pointId') pointId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item =
      await this.pointDomainFacade.findOneByIdOrFail(
        pointId,
        queryOptions,
      )

    return item
  }

  @Patch('/:pointId')
  async update(
    @Param('pointId') pointId: string,
    @Body() body: PointUpdateDto,
  ) {
    const item =
      await this.pointDomainFacade.findOneByIdOrFail(
        pointId,
      )

    const itemUpdated = await this.pointDomainFacade.update(
      item,
      body as Partial<Point>,
    )
    return itemUpdated
  }

  @Delete('/:pointId')
  async delete(@Param('pointId') pointId: string) {
    const item =
      await this.pointDomainFacade.findOneByIdOrFail(
        pointId,
      )

    await this.pointDomainFacade.delete(item)

    return item
  }
}
