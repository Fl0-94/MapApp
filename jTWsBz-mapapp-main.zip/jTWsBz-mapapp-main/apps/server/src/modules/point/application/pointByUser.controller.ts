import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { PointDomainFacade } from '@server/modules/point/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { PointApplicationEvent } from './point.application.event'
import { PointCreateDto } from './point.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class PointByUserController {
  constructor(
    
    private userDomainFacade: UserDomainFacade,
    
    private pointDomainFacade: PointDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/user/:userId/points')
  async findManyUserId(
    @Param('userId') userId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const user =
      await this.userDomainFacade.findOneByIdOrFail(
        userId,
      )

    const items =
      await this.pointDomainFacade.findManyByUser(
        user,
        queryOptions,
      )

    return items
  }

  @Post('/user/:userId/points')
  async createByUserId(
    @Param('userId') userId: string,
    @Body() body: PointCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, userId }

    const item = await this.pointDomainFacade.create(valuesUpdated)

    await this.eventService.emit<PointApplicationEvent.PointCreated.Payload>(
      PointApplicationEvent
        .PointCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
