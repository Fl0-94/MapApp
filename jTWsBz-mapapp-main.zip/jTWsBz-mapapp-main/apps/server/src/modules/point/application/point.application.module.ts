import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { PointDomainModule } from '../domain'
import { PointController } from './point.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { PointByUserController } from './pointByUser.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    PointDomainModule,

UserDomainModule,

],
  controllers: [
    PointController,
    
    PointByUserController,
    
  ],
  providers: [],
})
export class PointApplicationModule {}
