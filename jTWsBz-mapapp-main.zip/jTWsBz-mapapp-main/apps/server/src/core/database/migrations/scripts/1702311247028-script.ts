import { MigrationInterface, QueryRunner } from 'typeorm'

export class Script1702311247028 implements MigrationInterface {
  name = 'Script1702311247028'

  public async up(queryRunner: QueryRunner): Promise<void> {

try {
      await queryRunner.query(
        `
        INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('cb52b42f-9634-4af7-b0ac-80ea1a4b50fe', '1Nathanael_Langworth@gmail.com', 'termes', 'https://i.imgur.com/YfJQV5z.png?id=3', 'amplus', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('080372eb-0384-4124-b2f7-06dfb58b0213', '7Kacey3@yahoo.com', 'attollo aequus placeat', 'https://i.imgur.com/YfJQV5z.png?id=9', 'ventus', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('47ea00c7-8579-45b5-a274-08440fe87404', '13Erika_Schoen@yahoo.com', 'vir', 'https://i.imgur.com/YfJQV5z.png?id=15', 'comptus careo vehemens', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('fd09ea4c-6f54-483a-bd7d-00609d1a9b54', '19Tess49@gmail.com', 'sono verus curriculum', 'https://i.imgur.com/YfJQV5z.png?id=21', 'decretum capillus umquam', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('7793c013-70b0-4069-9282-f6fe9a7ba6f5', '25Kitty_Mitchell@hotmail.com', 'audentia adfero repellat', 'https://i.imgur.com/YfJQV5z.png?id=27', 'accusantium', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('07600ad2-0cb6-4931-9812-d5fb3dbd112e', '31Tina65@gmail.com', 'capitulus advoco usus', 'https://i.imgur.com/YfJQV5z.png?id=33', 'aggredior', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('2c66925a-ba62-4bf1-910e-13576ba1a6de', '43Alana_Klein@gmail.com', 'decens', 'https://i.imgur.com/YfJQV5z.png?id=45', 'subito', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('e01fd823-3db5-456e-9686-93fa203c3623', '49Marjolaine43@hotmail.com', 'textus certe', 'https://i.imgur.com/YfJQV5z.png?id=51', 'curo careo', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('e913cd77-b48b-4b81-9c9d-d9bd1aff02b4', '55Martina22@yahoo.com', 'velociter tabgo apparatus', 'https://i.imgur.com/YfJQV5z.png?id=57', 'defessus', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');

INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('1e925832-f00e-46b2-9aa0-c40b14bc8c27', 'reiciendis', 'adipiscor caute', 'damno circumvenio sophismata', '64Morton17@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=65', 'https://i.imgur.com/YfJQV5z.png?id=66', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('2bd3452f-db89-47d6-86d5-568845702270', 'adhaero', 'claro auctus', 'quod', '71Amos_Mills@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=72', 'https://i.imgur.com/YfJQV5z.png?id=73', '7793c013-70b0-4069-9282-f6fe9a7ba6f5');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('5bb08e2e-af46-4995-9668-ff0102c0cfa9', 'valde beneficium nisi', 'consequuntur custodia', 'admoneo vox', '78Margarita45@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=79', 'https://i.imgur.com/YfJQV5z.png?id=80', '07600ad2-0cb6-4931-9812-d5fb3dbd112e');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('0f3a68d1-7c98-4e36-8a56-f9020c57d5be', 'auditor tersus', 'alii', 'ventito', '85Keon_Pfannerstill@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=86', 'https://i.imgur.com/YfJQV5z.png?id=87', '080372eb-0384-4124-b2f7-06dfb58b0213');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('3f6685eb-dbd1-493c-8eed-a845d6e28b7b', 'custodia', 'pauper', 'timor tremo constans', '92Alysson47@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=93', 'https://i.imgur.com/YfJQV5z.png?id=94', 'cb52b42f-9634-4af7-b0ac-80ea1a4b50fe');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('7d1aee0d-961f-4ee3-979f-0a2c22d39592', 'tracto quam', 'triumphus pecus', 'quis', '99Junius.Hagenes@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=100', 'https://i.imgur.com/YfJQV5z.png?id=101', 'cb52b42f-9634-4af7-b0ac-80ea1a4b50fe');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('5994da4f-4ccb-47bb-9da7-f20b9549d4f5', 'unus alius ager', 'acquiro cultura', 'somniculosus depulso', '106Murphy68@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=107', 'https://i.imgur.com/YfJQV5z.png?id=108', 'e01fd823-3db5-456e-9686-93fa203c3623');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('2f644b2a-749f-4ac5-b6d9-f8df4aa629a7', 'aequitas', 'comptus debeo', 'ustilo trado dolore', '113Jalen.Kilback60@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=114', 'https://i.imgur.com/YfJQV5z.png?id=115', '47ea00c7-8579-45b5-a274-08440fe87404');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('304f9f51-85a5-4a3a-aae4-5f8435e97e4f', 'commemoro damnatio atavus', 'laboriosam', 'subnecto conventus', '120Nolan.Wiegand67@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=121', 'https://i.imgur.com/YfJQV5z.png?id=122', '7793c013-70b0-4069-9282-f6fe9a7ba6f5');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('7f249fa4-bff8-4984-a6ef-3b6ea4e82f5c', 'vesica', 'solum aperio', 'tredecim credo', '127Olga.Wisoky@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=128', 'https://i.imgur.com/YfJQV5z.png?id=129', 'e913cd77-b48b-4b81-9c9d-d9bd1aff02b4');

INSERT INTO "point" ("id", "latitude", "longitude", "userId") VALUES ('1c058b6d-e8a7-444f-96de-813cd8930cf3', 348, 24, '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "point" ("id", "latitude", "longitude", "userId") VALUES ('dbdf5339-dac6-489d-ac77-a33b9e62a012', 948, 409, '47ea00c7-8579-45b5-a274-08440fe87404');
INSERT INTO "point" ("id", "latitude", "longitude", "userId") VALUES ('325b7594-d48d-4d06-adaa-e13c852be747', 83, 217, '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "point" ("id", "latitude", "longitude", "userId") VALUES ('72ddc9e9-93cd-4362-8fa1-8006ad3abff6', 462, 993, '7793c013-70b0-4069-9282-f6fe9a7ba6f5');
INSERT INTO "point" ("id", "latitude", "longitude", "userId") VALUES ('81e950d0-2924-4083-9668-29682c05de84', 893, 571, '07600ad2-0cb6-4931-9812-d5fb3dbd112e');
INSERT INTO "point" ("id", "latitude", "longitude", "userId") VALUES ('028fd04b-ff1b-424a-82ca-67e9c6a23e64', 97, 414, '080372eb-0384-4124-b2f7-06dfb58b0213');
INSERT INTO "point" ("id", "latitude", "longitude", "userId") VALUES ('e6ccef44-c0cb-42d7-a17f-8e029034e98b', 521, 624, '2c66925a-ba62-4bf1-910e-13576ba1a6de');
INSERT INTO "point" ("id", "latitude", "longitude", "userId") VALUES ('0b44cde8-8fd3-4633-a682-fffc33828eca', 622, 649, '2c66925a-ba62-4bf1-910e-13576ba1a6de');
INSERT INTO "point" ("id", "latitude", "longitude", "userId") VALUES ('5dcb793f-9b2b-4541-8ec6-6a1dcc67554b', 439, 633, 'cb52b42f-9634-4af7-b0ac-80ea1a4b50fe');
INSERT INTO "point" ("id", "latitude", "longitude", "userId") VALUES ('33686e45-dc50-40cd-8b5b-64d016c10f46', 323, 749, '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
    `,
      )
    } catch (error) {
      // ignore
    }

}

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
